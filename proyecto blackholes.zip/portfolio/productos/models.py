from django.db import models

# Create your models here.
# 
class Productos(models.Model):
    nombre = models.CharField(max_length=30)
    descripcion = models.CharField(max_length=30)
    disponible = models.BooleanField()
    fechaIncorporacion = models.DateField()
    correoProveedor = models.EmailField()

  #ESTO EQUIVALE A CREAR UNA TABLA CON ESTOS CAMPOS SIN NECESIDAD DE SABER SQL
