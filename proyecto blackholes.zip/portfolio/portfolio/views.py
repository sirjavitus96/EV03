from itertools import product
from django.http import HttpResponse
import datetime
from django.shortcuts import render
from django.template import Template, Context
from productos.models import Productos
from clientes.models import Clientes
from ventas.models import Ventas


def saludo(request):
    return render(request, "index.html")


def quienesSomos(request):
    return render(request, "QuienesSomos.html")


def login(request):
    return render(request, "loginyregistro.html")


def registro(request):
    return render(request, "registro.html")


def Seguimiento(request):
    return render(request, "Seguimiento.html")


def tienda(request):
    return render(request, "tienda.html")


# def tienda(request):
#     clientes = Clientes.objects.filter(nombre__icontains="")
#     contexto = {'clientes': clientes}
#     return render(request, "tienda.html", contexto)


def producto_n(request):
    productos = Productos.objects.all()
    contexto1 = {'productos': productos}
    return render(request, "../ventas/templates/tienda.html", productos)


# def tienda(request):
#     clientes = Clientes.objects.filter(nombre__icontains="")
#     contexto = {'clientes': clientes}
#     return render(request, "tienda.html", contexto)
