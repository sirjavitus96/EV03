from django.db import models

#Create your models here.

class Ventas(models.Model):
  idventa = models.IntegerField()
  descripcion_v= models.CharField(max_length=30)
  estado_v = models.BooleanField()
  fecha_v = models.DateField()
  suscriptor_v = models.BooleanField()

