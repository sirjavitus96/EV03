from django.db import models

# Create your models here.
class Clientes(models.Model):
  nombre = models.CharField(max_length=30)
  password = models.CharField(max_length=30)
  suscrito = models.BooleanField()
  correoCliente = models.EmailField()